package com.mhl.service;

import com.mhl.dao.DiningTableDAO;
import com.mhl.domain.DiningTable;

import java.util.List;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class DiningTableService {

     private DiningTableDAO diningTableDAO= new DiningTableDAO();

//     public DiningTable selectDiningTableState(String id) { //查询餐桌
//         return diningTableDAO.querySingle("select * from diningtable where id = ?", DiningTable.class, id);
//     }
    public List<DiningTable> list() {   // 查询餐桌id，state
        return diningTableDAO.queryMultiply("select id, state from diningtable", DiningTable.class);
    }

    public DiningTable getDiningTableById(int id) { //根据id获取餐桌信息
        return diningTableDAO.querySingle("select * from diningtable where id = ?", DiningTable.class, id);
    }

    public boolean orderDiningTable(int id, String orderName, String orderTel) {
        int update = diningTableDAO.update
                ("update diningtable set state='已预定', orderName=?, orderTel=? where id = ?", orderName, orderTel, id);
        return update > 0;
    }

    //更新餐桌状态的方法
    public boolean updateDiningTableState(int id, String state) {
        int update = diningTableDAO.update("update diningtable set state = ? where id = ?", state, id);
        return update > 0;
    }

    //重置餐桌
    public boolean updateDiningTableToFree(int id, String state) {
        int update = diningTableDAO.update("update diningtable set state = ?, orderName = '', orderTel = '' where id = ?", state, id);
        return update > 0;
    }
}
