package com.mhl.service;

import com.mhl.dao.BillDAO;
import com.mhl.domain.Bill;

import java.util.List;
import java.util.UUID;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class BillService {

    private BillDAO billDAO = new BillDAO();
    private MenuService menuService = new MenuService();
    private DiningTableService diningTableService = new DiningTableService();

    public boolean orderMenu(int menuId, int nums, int diningTableId) {
        String billID = UUID.randomUUID().toString(); //生成UUID

        //生成账单
        int update = billDAO.update("insert into bill values(null, ?, ?, ?, ?, ?, now(), '未支付')",
                billID, menuId, nums, menuService.getMenuById(menuId).getPrice() * nums, diningTableId);

        if (update <= 0) {
            return false;
        }

        //更新餐桌状态
        return diningTableService.updateDiningTableState(diningTableId, "就餐中");
    }

    // 返回所有账单
    public List<Bill> list() {
        return billDAO.queryMultiply("select * from bill", Bill.class);
    }

    //查看某指定餐桌未结账的账单
    public boolean hasPayBillByDiningTableId(int diningTableId) {
        Bill bill = billDAO.querySingle("select * from bill where diningTableId = ? and state = '未支付' limit 0, 1", Bill.class, diningTableId);
        return bill != null;
    }

    //完成结账（餐桌存在 且 有未结账账单）
    public boolean payBill(int diningTableId, String payMode) {
        int update = billDAO.update("update bill set state = ? where diningTableId = ? and state = '未支付'", payMode, diningTableId);
        if (update <= 0) {
            return false;
        }

        if (diningTableService.updateDiningTableToFree(diningTableId, "空")) {
            return true;
        }
        return true;
    }
}
