package com.mhl.service;

import com.mhl.dao.EmployeeDAO;
import com.mhl.domain.Employee;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 * 完成对Employee表的操作（调用EmployeeDAO）
 */
public class EmployeeService {
     private EmployeeDAO employeeDAO = new EmployeeDAO(); //创建对象操作employdao

    //根据empId & pwd 返回对象
    public Employee getEmployeeByIdAndPwd(String empId, String pwd) {
        return employeeDAO.querySingle("select * from employee where empId = ? and pwd = md5(?)", Employee.class, empId, pwd);
    }
}
