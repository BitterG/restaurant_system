package com.mhl.service;

import com.mhl.dao.MenuDAO;
import com.mhl.domain.Menu;

import java.util.List;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 * 对Menu表的操作 - 调用MenuDAO
 */
public class MenuService {

    private MenuDAO menuDAO = new MenuDAO();

    //查询菜品菜单
    public List<Menu> list() {
        return menuDAO.queryMultiply("select * from menu", Menu.class);
    }

    // 查询获得价格
    public Menu getMenuById(int id) {
        return menuDAO.querySingle("select * from menu where id = ?", Menu.class, id);
    }

}
