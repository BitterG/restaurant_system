package com.mhl.dao;

import com.mhl.domain.Employee;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class EmployeeDAO extends BasicDAO<Employee>{
    //可以添加特有方法
}
