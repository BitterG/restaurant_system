package com.mhl.dao;

import com.mhl.utils.JDBC_Druid_Utils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月04日
 * BasicDao,父类
 */
@SuppressWarnings({"all"})
public class BasicDAO<T> {

    private QueryRunner qr = new QueryRunner();

    //通用dml方法
    public int update(String sql, Object... parameters) {

        Connection connection = null;
        try {
            connection = JDBC_Druid_Utils.getConnection();

            int update = qr.update(connection, sql, parameters);
            return update;
        } catch (SQLException e) {
            throw new RuntimeException(e);  //编译异常转运行异常
        } finally {
            JDBC_Druid_Utils.close(null, connection, null);
        }
    }


    //返回多对象针对任意表
    public List<T> queryMultiply(String sql, Class<T> clazz, Object... parameters) {

        Connection connection = null;

        try {
            connection = JDBC_Druid_Utils.getConnection();
            return qr.query(connection, sql, new BeanListHandler<T>(clazz), parameters);
        } catch (SQLException e) {
            throw new RuntimeException(e);  //编译异常转运行异常
        } finally {
            JDBC_Druid_Utils.close(null, connection, null);
        }
    }

    //查询单行结果通用方法
    public T querySingle(String sql, Class<T> clazz, Object... parameters) {

        Connection connection = null;

        try {
            connection = JDBC_Druid_Utils.getConnection();
            return qr.query(connection, sql, new BeanHandler<T>(clazz), parameters);
        } catch (SQLException e) {
            throw new RuntimeException(e);  //编译异常转运行异常
        } finally {
            JDBC_Druid_Utils.close(null, connection, null);
        }
    }

    //查询单行单列方法，返回单值方法
    public Object quaryScalar(String sql, Object... parameters) {

        Connection connection = null;

        try {
            connection = JDBC_Druid_Utils.getConnection();
            return qr.query(connection, sql, new ScalarHandler(), parameters);
        } catch (SQLException e) {
            throw new RuntimeException(e);  //编译异常转运行异常
        } finally {
            JDBC_Druid_Utils.close(null, connection, null);
        }
    }
}
