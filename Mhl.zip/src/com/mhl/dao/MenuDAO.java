package com.mhl.dao;

import com.mhl.domain.Menu;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class MenuDAO extends BasicDAO<Menu>{

}
