package com.mhl.view;

import com.mhl.domain.Bill;
import com.mhl.domain.DiningTable;
import com.mhl.domain.Employee;
import com.mhl.domain.Menu;
import com.mhl.service.BillService;
import com.mhl.service.DiningTableService;
import com.mhl.service.EmployeeService;
import com.mhl.service.MenuService;
import com.mhl.utils.Utility;

import java.util.List;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class MHLView {

    private boolean loop = true; //控制循环变量
    private String key = "";
    private EmployeeService employeeService = new EmployeeService();
    private DiningTableService diningTableService = new DiningTableService();
    private MenuService menuService = new MenuService();
    private BillService billService = new BillService();

    public static void main(String[] args) {
        MHLView mhlView = new MHLView();
        mhlView.mainMenu();
    }

    //显示菜品菜单
    public void listMenu() {
        System.out.println("===========显示菜品列表===========");
        List<Menu> menus = menuService.list();
        for (Menu menu : menus) {
            System.out.println(menu);
        }
        System.out.println("================================");
    }

    public void showTableInfo() {
        System.out.println("===========显示餐桌状态===========");
        List<DiningTable> list = diningTableService.list();
        for (DiningTable diningTable : list) {
            System.out.println(diningTable);
        }
        System.out.println("================================");
    }

    //显示所有账单信息
    public void listBill() {
        List<Bill> allBillList = billService.list();
        System.out.println("编号\t\t菜品编号\t\t菜品量\t\t金额\t\t餐桌号\t\t日期\t\t\t\t\t\t\t\t状态");
        for (Bill bill : allBillList) {
            System.out.println(bill);
        }
        System.out.println("===================================================================");
    }

    //结账
    public void payBill() {
        System.out.println("====================结账====================");
        System.out.print("请选择结账的餐桌编号(-1 退出)：");
        int tableId = Utility.readInt();
        if (tableId == -1) {
            System.out.println("取消结账");
            return;
        }
        //验证餐桌合法
        DiningTable diningTableById = diningTableService.getDiningTableById(tableId);
        if (diningTableById == null) {
            System.out.println("餐桌号不存在");
            return;
        }
        //验证指定餐桌是否有需结账的账单
        boolean bill = billService.hasPayBillByDiningTableId(tableId);
        if (!bill) {
            System.out.println("该餐桌无账单需要支付");
            return;
        }
        System.out.print("选择结账方式(现金/微信/支付宝)[回车表示退出]：");
        String payType = Utility.readString(10, "");    //直接回车返回默认值 ""
        if ("".equals(payType)) {
            System.out.println("取消结账");
            return;
        }
        char key = Utility.readConfirmSelection();
        if (key == 'Y') {
            //调用BillService中的结账方法
            if (billService.payBill(tableId, payType)) {
                System.out.println("===结账成功！！！===");
            }
        } else {
            System.out.println("结账失败");
        }
    }
    //完成点餐
    public void orderMenu() {
        System.out.println("===========点餐服务===========");
        System.out.print("请输入点餐桌号(-1 退出)：");
        int orderDiningTableId = Utility.readInt();
        if (orderDiningTableId == -1) {
            System.out.println("取消点餐");
            return;
        }
        System.out.print("请输入点餐菜品编号(-1 退出)：");
        int orderMenuId = Utility.readInt();
        if (orderMenuId == -1) {
            System.out.println("取消点餐");
            return;
        }
        System.out.print("请输入菜品数量(-1 退出)：");
        int menuNums = Utility.readInt();
        if (menuNums == -1) {
            System.out.println("取消点餐");
            return;
        }
        //验证餐桌号是否合法
        DiningTable diningTable = diningTableService.getDiningTableById(orderDiningTableId);
        if (diningTable == null) {
            System.out.println("餐桌号不存在");
            return;
        }
        //验证菜品编号
        Menu menu = menuService.getMenuById(orderMenuId);
        if (menu == null) {
            System.out.println("菜品编号不存在");
            return;
        }
        //完成点餐
        if (billService.orderMenu(orderMenuId, menuNums, orderDiningTableId)) {
            System.out.println("点餐成功");
        } else {
            System.out.println("点餐失败");
        }
    }

    //预定方法
    public void orderDiningTable() {
        System.out.println("=============预定餐桌=============");
        System.out.print("请选择餐桌编号(输入-1退出预定)");
        int orderId = Utility.readInt();
        if (orderId == -1) {
            System.out.println("=============取消预定=============");
            return;
        }
        char key = Utility.readConfirmSelection();
        if (key == 'Y') {
            DiningTable diningTable = diningTableService.getDiningTableById(orderId);
            if (diningTable == null) {
                System.out.println("=============餐桌不存在=============");
                return;
            } else if (!("空".equals(diningTable.getState()))) { //不为空状态
                System.out.println("=============餐桌已满=============");
                return;
            } else {
                //更新状态
                System.out.print("请输入预定人姓名：");
                String orderName = Utility.readString(50);
                System.out.print("请输入预定人联系电话：");
                String orderTel = Utility.readString(50);
                if (diningTableService.orderDiningTable(orderId, orderName, orderTel)) {
                    System.out.println("=============预定成功=============");
                } else {
                    System.out.println("=============预定失败=============");
                }
            }
        } else {
            System.out.println("=============取消预定=============");
        }
    }

    public void mainMenu() {

        while(loop) {
            System.out.println("=============主菜单=============");
            System.out.println("\t\t1 登录");
            System.out.println("\t\t2 退出");
            System.out.print("输入选择：");
            key = Utility.readString(1);

            switch(key) {
                case "1":
                    System.out.println("登录");
                    System.out.print("请输入员工号：");
                    String empId = Utility.readString(50);
                    System.out.print("请输入  密码：");
                    String pwd = Utility.readString(50);
                    //数据库判断密码
                    Employee employee = employeeService.getEmployeeByIdAndPwd(empId, pwd);
                    if (employee != null) { // 不为空表示用户存在
                        System.out.println("=========登录成功[" + employee.getName() + "]=========\n");
                        //显示二级菜单
                        mainMenu_2();
                    } else {
                        System.out.println("登录失败");
                    }
                    break;
                case "2":
                    System.out.println("退出");
                    loop = false;
                    break;
                default:
                    System.out.println("输入有误，请重新输入");
            }
        }
    }

    public void mainMenu_2() {
        while (loop) {
            System.out.println("===========二级菜单===========");
            System.out.println("\t\t 1 显示餐桌状态");
            System.out.println("\t\t 2 预定餐桌");
            System.out.println("\t\t 3 显示所有菜品");
            System.out.println("\t\t 4 点餐服务");
            System.out.println("\t\t 5 查看账单");
            System.out.println("\t\t 6 结账");
            System.out.println("\t\t 9 退出菜单");
            System.out.print("输入选择：");
            key = Utility.readString(1);

            switch (key) {
                case "1":   //显示所有餐桌状态
                    showTableInfo();
                    break;
                case "2":   //预定餐桌
                    orderDiningTable();
                    break;
                case "3":   //显示菜品列表
                    listMenu();
                    break;
                case "4": //点餐服务
                    orderMenu();
                    break;
                case "5": //查看所有账单
                    listBill();
                    break;
                case "6": //结账
                    payBill();
                    break;
                case "9":
                    System.out.println("退出菜单");
                    loop = false;
                    break;
                default:
                    System.out.println("输入有误，请重新输入");
            }
        }
    }
}
