package com.mhl.domain;

/**
 * @author 苦瓜
 * 我亦无他，惟手熟尔。
 * Time:2022年06月05日
 */
public class Menu {
    /**
     * create table menu (
     * 	id int primary key auto_increment,
     * 	`name` varchar(50) not null default '',
     * 	type varchar(50) not null default '',
     * 	price double not null  default 0
     * )charset=utf8;
     */
    private Integer id;
    private String name;
    private String type;
    private Double price;

    public Menu(Integer id, String name, String type, Double price) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.price = price;
    }

    public Menu() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "菜品编号: " + id + '\t' + "菜品名称: " + name + '\t' + "菜品类别: " + type + '\t' + "菜品价格: " + price;
    }
}
